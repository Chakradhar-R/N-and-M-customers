import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class DeliveryManager {

    /**
     * Delivers the orders to the customers by assigning the delivery boys to each order.
     *
     * @param N - Number of Customer Orders
     * @param M - Number of Delivery Boys
     * @param orders - orders[][0] - Order Placement Time, orders[][1] - Travel Time from Restaurant
     *               to Customer
     */
    private void deliveryFood(int N, int M, int[][] orders) {
        int[] deliveryBoys = new int[M];
        List<Order> orderList = new ArrayList<>();
        for (int i = 1; i <= N; i++) {
            orderList.add(new Order(i, orders[i - 1][0], orders[i - 1][1]));
        }
        Collections.sort(orderList);
        List<String> assignments = new ArrayList<>();

        for (Order order : orderList) {
            boolean assigned = false;
            for (int i = 0; i < M; i++) {
                if (deliveryBoys[i] <= order.getOrderTime()) {
                    deliveryBoys[i] = order.getOrderTime() + order.getTravelTime();
                    assignments.add("C" + order.getIndex() + "-D" + (i + 1));
                    assigned = true;
                    break;
                }
            }

            if (!assigned) {
                assignments.add("C" + order.getIndex() + "-No Food:-(");
            }
        }

        // Print Result
        printResult(assignments);
    }

    private void printResult(@NotNull List<String> assignments) {
        for (String assString : assignments) {
            System.out.println(assString);
        }
    }

    public static void main(String[] args) {

        // Test case 1
        int N = 6;
        int M = 2;
        int[][] orders = {{1, 10}, {4, 20}, {15, 5}, {22, 20}, {24, 10}, {25, 10}};

        final DeliveryManager deliveryManager = new DeliveryManager();
        deliveryManager.deliveryFood(N, M, orders);
    }
}
