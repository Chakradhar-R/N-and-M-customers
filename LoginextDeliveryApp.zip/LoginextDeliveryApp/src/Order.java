import org.jetbrains.annotations.NotNull;

public class Order implements Comparable<Order> {

    private final int index;
    private final int orderTime;
    private final int travelTime;

    public Order(int index, int orderTime, int travelTime) {
        this.index = index;
        this.orderTime = orderTime;
        this.travelTime = travelTime;
    }

    public int getIndex() {
        return index;
    }

    public int getOrderTime() {
        return orderTime;
    }

    public int getTravelTime() {
        return travelTime;
    }

    @Override
    public int compareTo(@NotNull Order order) {
        return this.orderTime - order.orderTime;
    }

    @Override
    public String toString() {
        return "Order{"
                + "index="
                + index
                + ", orderTime="
                + orderTime
                + ", travelTime="
                + travelTime
                + '}';
    }
}
